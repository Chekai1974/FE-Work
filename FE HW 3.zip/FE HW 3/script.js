// 1 В программе объявлена переменная word со строковым значением. Используя цикл, разверните слово.
let a = "Marko"
let result = ""
for (let i = a.length - 1; i >= 0; i--) {
    result += a[i]
}
console.log(result);


// 2 Напишите функцию, которая в качестве аргументов получает слово и определяет, является ли оно палиндромом. Если да, функция возвращает true, в ином случае false.
// Палиндром - слово, одинаково читающееся как слева направо, так и справа налево.
function task(params) {
    let palindrome = params.split('')
    let isPalindrome = true
    for (let index = 0; index < palindrome.length; index++) {
        let elem = palindrome[index]
    
        if (elem !== palindrome[palindrome.length -1 - index]) {
            isPalindrome = false
        }
    }
    return isPalindrome
    
}

console.log(task('12321'));
console.log(task('1221'));
console.log(task('1231'));


// 3 Используя цикл, выведите в консоль сумму чисел из диапазона значений от 0 до 50 кратные 5.
let sum = 0
for (let i = 0; i <= 50; i++) {
    if (i % 5 ===0) {
        sum+=i
    }
   
}
console.log(sum);

//4 Написать цикл, который выводит только названия товаров
const obj = {
    Lime: 220,
    Pear: 110,
    Apple: 150,
}
for (const key in obj) {
    console.log(key);
}
// // 5 Написать цикл, который выводит для каждого товара стоку по маске “<название> (<цена>)”
for (const key in obj) {
    console.log(`“<${key}> (<${obj[key]}>)”`);
}

// 6 Написать функцию, которая получает в качестве аргумента массив из объектов и возвращает объект с самым дорогим товаром.
// let arr = [
//     { Lime: 220 },
//     { Pear: 110 },
//     { Apple: 150 }
// ]
// for (let i = 0; i < arr.length; i++) {
//     let elem = arr[i];
//     for (const key in elem) {                    //// не знаю как сделать 
//         console.log(elem[key]);
//     }
// }