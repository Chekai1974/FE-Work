// const arr = [
// {
//     title: "BMW",
//     price: "40000",
//     count: "15"
//     },
    
//     {
//     title: "Toyota",
//     price: "20000",
//     count: "13"
//     },
    
//     {
//     title: "Ford",
//     price: "30000",
//     count: "20"
//     },
    
//     {
//     title: "Chevrolet",
//     price: "60000",
//     count: "9"
//     },

//     {
//     title: "Volkswagen",
//     price: "30000",
//     count: "13"
// },
// ]
// const div = document.createElement('div')
// for (let i = 0; i < arr.length; i++) {

//     let list = document.createElement('ol')

//     let title = document.createElement('li')
//     title.innerText = arr[i].title

//     let price = document.createElement('li')
//     price.innerText = arr[i].price

//     let count = document.createElement('li')
//     count.innerText = arr[i].count

//     list.append(title, price, count)
//     div.append(list)
// }
// document.body.append(div )


const arr = [
    {
        n: "No.",
        f: "Full Name",
        p: "Position",
        s: "Salary"
        },
        
        {
        namber: "1",
        name: "Bill Gates",
        position: "Founder Microsoft",
        salary: "$1000"
        },
        
        {
        namber: "2",
        name: "Steve Jobs",
        position: "Founder Apple",
        salary: "$1200"
        },
        
        {
        namber: "3",
        name: "Larry Page",
        position: "Founder Google",
        salary: "$1100"
        },
    
        {
        namber: "4",
        name: "Mark Zuckerberg",
        position: "Founder Facebook",
        salary: "$1300"
    },
]

let div = document.createElement('div')  

let table = document.createElement('table')
table.setAttribute('border', '1px')
table.setAttribute('width', '400px')

let tbody = document.createElement('tbody')    

let thead = document.createElement('thead')

table.append(tbody,thead)   

for (let i = 0; i < 1; i++) {
    let th1 = document.createElement('th')
    let th2 = document.createElement('th')
    let th3 = document.createElement('th')
    let th4 = document.createElement('th')
    th1.innerText= `${arr[i].n}`
    th2.innerText= `${arr[i].f}`
    th3.innerText= `${arr[i].p}`
    th4.innerText= `${arr[i].s}`
    thead.append(th1,th2,th3,th4)
    
}
for (let i = 1; i < 5; i++) {
    let tr1 = document.createElement('tr')

    let td1 = document.createElement('td')
    let td2 = document.createElement('td')
    let td3 = document.createElement('td')
    let td4 = document.createElement('td')

    td1.innerText= `${arr[i].namber } `
    td2.innerText= `${arr[i].name }`
    td3.innerText= `${arr[i].position }`
    td4.innerText= `${arr[i].salary }`
    tr1.append(td1,td2,td3,td4)
    tbody.append(tr1)
}
div.append(table)
document.body.append(div)