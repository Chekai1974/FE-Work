// https://learn.javascript.ru/object

// Проверка на пустоту
function example(obj) {
    for (let key in obj) {
        return false
    }return true
}

//Сумма свойств объекта
let sum = 0;
let salaries = {
    Marko: 100,
    Sasha: 200,
    Dmitro: 90
}
for (let kay in salaries) {
    sum+= salaries[kay]
}
console.log(sum);
 
//Умножаем все числовые свойства на 2
let double = {
    title: "May menu",
    width: 130,
    height: 40
}
function test(double) {
for (let key in double) {
    if (typeof double[key] == 'number') {
        double[key] *= 2
        
        }
    }
    return double
}
test(double)
console.log(double);

//https://learn.javascript.ru/function-basics#tasks

//Перепишите функцию, используя оператор '?' или '||'
function checkAge(age) {
    return (age > 18) ?  true :  confirm('Родители разрешили?');
}
function checkAge(age) {
    return (age > 18) || confirm('Родители разрешили?');
}

//Функция min(a, b)
function min(first, second) {
    first > second ? console.log(first) : console.log(second);
}
min(10, 9)

//Функция pow(x,n)
// let res = 0;
// let first = prompt('1');
// let second = prompt('2')
// function pow(first, second) {
//     res = first**second
//     console.log(res);
//     return res
// }
// if (second < 1) {
//     alert(`Степень ${second} не поддерживается, используйте натуральное число`);
// } else {
//     alert( pow(first, second) );
// }
//---
// function pow(x, n) {
//     let result = x;
  
//     for (let i = 1; i < n; i++) {
//       result *= x;
//     }
                                                     //ЭТО ОТВЕТ НА САЙТЕ!
                                                     // Зачем здесь for ?
                                                     // У меня и так получилось или у меня не верно?
//     return result;
//   }
  
//   let x = prompt("x?", '');
//   let n = prompt("n?", '');
  
//   if (n < 1) {
//     alert(`Степень ${n} не поддерживается, используйте натуральное число`);
//   } else {
//     alert( pow(x, n) );
//   }



//Задача 1: Дан многомерный массив Выведите с его помощью слово 'голубой'.
const arr = {
    'ru':['голубой', 'красный', 'зеленый'],
    'en':['blue', 'red', 'green'],
};
console.log(arr.ru[0]);

// Задача 2:  Дан объект obj с ключами Коля, Вася, Петя с элементами '200', '300', '400'. 
// С помощью цикла выведите на экран строки такого формата: 'Коля - зарплата 200 долларов.'.
const obj = {
    Коля: 200,
    Вася: 300,
    Петя: 400,
}
for (key in obj) {
    console.log(`${[key]} - зарплата ${obj[key]} долларов`);
}

// Задача 3: Дан объект {js:['jQuery', 'Angular'], php: 'hello', css: 'world'}. Выведите с его помощью слово 'jQuery'.
const object = {
    js: ['jQuery', 'Angular'],
    php: 'hello',
    css: 'world'
}                               
console.log(object.js[0]);// ИЛИ ТРЕБОВАЛОСЬ ЧТО-ТО ДРУГОЕ?

// Задача 4: Создайте двухмерный массив. Первые два ключа - это 'ru' и 'en'.
//Пусть первый ключ содержит элемент, являющийся массивом названий дней недели по - русски,
// а второй - по - английски.Выведите с помощью этого массива понедельник по - русски и среду по английский(пусть понедельник - это нулевой день).
let week = {
    'ru':['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'],
    'eu':['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sanday']
}
console.log(week.ru[0]);
console.log(week.eu[2]);

// Задача 5: Создайте объект с днями недели.
// Ключами в нем должны служить номера дней от начала недели(понедельник - первый и т.д.).
// Выведите на экран текущий день недели.
const days = {
    1:'Понедельник',
    2:'Вторник',
    3:'Среда',
    4:'Четверг',
    5:'Пятница',
    6:'Суббота',
    7:'Воскресенье'
}
console.log(days[3])

// Задача 6:Написать функцию, которая получает в качестве аргумента число и строку,
// где число обозначает сколько раз должна быть добавлена эта строка в объект.
// Возвращает массив из этих строк.Например: передаем строку “dog” и цифру 3,
// в результате мы получаем { "dog0" : "dog0", "dog1": "dog1", "dog2": "dog2" }.
// let result = [];
// function dogs(str, num) {
//     for (let i = 0; i < num; i++) {
//     }                                          //НЕ СМОГ
//     console.log(result);
// }
// dogs('dog', 3)

// Задача 7:Написать функцию, которая получает в качестве аргумента массив.
// для расчета суммы четных чисел в массиве.Так же написать новую функцию
// для расчета суммы нечетных чисел в массиве.
// Написать функцию, которая принимает как аргумент две полученные суммы и
// выводит наибольшее из них.
let masiv = [2, 3, 4, 5, 6,11]
let arrSum1 = 0;
function main(array1) {
    for (let i = 0; i < array1.length; i++) {
        if (array1[i] % 2 === 0) {
            arrSum1 += array1[i]
        }
    }
    console.log(arrSum1);
    return arrSum1
}
main(masiv)

let arrSum2 = 0;
function main2(array2) {
   
    for (let i = 0; i < array2.length; i++) {
        if (array2[i] % 2 !== 0) {
            arrSum2 += array2[i]
        }
    }
    console.log(arrSum2);
    return arrSum2
}
main(masiv)

function resultMain(first,second) {
    if (first > second) {
        console.log("More: "+first);
    } else {
        console.log("More: "+second);
    }
}
resultMain(arrSum1,arrSum2)