
// ----------------------1---------------------
let nikname = "Ilya";

alert( `hello ${1}` ); // ? hello 1

alert( `hello ${"name"}` ); // ? hello name

alert(`hello ${nikname}`); // ? hello Ilya

// ----------------------2---------------------
let q = 3;
while (q) {
  alert( q-- );   // до 0
}

//
let w = 0;
while (++w < 5) alert(w);   // до 4

let e = 0;
while (e++ < 5) alert(e);   // до 5

//
for (let i = 0; i < 5; i++) alert( i );  // до 4

for (let i = 0; i < 5; ++i) alert(i);  // до 4

//
for (let i = 2; i <=10; i++) {
    if (i % 2 == 0) {            // to while
        alert(i)
    }
}
let t = 0;
while (t <=10) {
    if (t % 2 == 0) {          // in while
        alert(t)
    }
    t++;
}

//
for (let i = 0; i < 3; i++) {
    alert( `number ${i}!` );    // to while
}
let r = 0;
while (r < 3) {
    alert(`number ${r}`);      // in while
    r++;
}


let u;
do {
  u = prompt("Введите число больше 100?");
} while (u <= 100 && u);


let num = 10;
some:for (let i = 2; i <= num; i++) {
    for (let j = 2; j < i; j++) {
        if (i % j == 0) {
            continue some;
        }
       
    }
    alert(i)
}

//----------------------3---------------------

let styles = ['Джаз', 'Блюз']
styles.push('Рок-н-ролл')
styles[(styles.length - 1) / 2] = 'Классика'
styles.shift()
styles.unshift('Рэп','Регги')
alert(styles)


function sumInput() {

    let numbers = [];
  
    while (true) {
  
      let value = prompt("Введите число", 0);
  
      if (value === "" || value === null || !isFinite(value)) break;   // ПЫТАЛСЯ НО САМ НЕ СОГ((( Обьясни пожалуйста на уроке !
  
      numbers.push(+value);
    }
  
    let sum = 0;
    for (let number of numbers) {
      sum += number;
    }
    return sum;
  }
  
  alert( sumInput() );

let c = "2" > "32"
alert(c)

//----------------------4---------------------




//----------------------5---------------------

let age = 4;
if (!(age >= 14 && age < 90)) {
    alert(age)
}

if (age < 14 || age > 90) {
    alert(age)
}

let login = prompt('Who are you')

if (login === "Admin") {
    
    let password = prompt('Password?')
    if (password === 'Nimda') {
        alert("Welcome")
    } else if (password === null || password === '') {
        alert("Cancel")
    } else {
        alert("Password is not corect")
    }
} else if (login === null || login === '') {
    alert('Cancel')
} else {
    alert("I don't now you!")
}
//----------------------6---------------------

let namee = prompt("Какое «официальное» название JavaScript?")
if (namee === 'ECMAScript') {
    alert("Верно!")
} else {
    alert("Не знаете? ECMAScript!")
}

let value = prompt("Enter value")
if (value > 0 ) {
    alert(1)
} else if(value < 0){
    alert(-1)
} else {
    alert(0)
}

let a = 2
let b = 2
let res;
res = (a + b < 4) ? alert("Minder") : alert("Meer")


let message;
message = (login == "Сотрудник") ? "Привет" :
    (loginn == "Директор") ? "Здравствуйте" :
        (login == '') ? "Нет логина" :
            ""